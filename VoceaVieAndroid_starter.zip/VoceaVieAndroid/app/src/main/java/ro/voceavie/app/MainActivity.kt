package ro.voceavie.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.InputType
import android.graphics.Color
import java.io.BufferedReader
import java.io.InputStreamReader

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var status: TextView
    private lateinit var chapterSpinner: Spinner
    private lateinit var textPreview: EditText
    private val chapters = mutableListOf<Pair<String, String>>()
    private val characters = mutableListOf("Narator", "Personaj feminin", "Personaj masculin")
    private val voiceAssignments = mutableMapOf<String, String>()
    private val PICK_TEXT = 101
    private val PICK_MODEL = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(8, 14, 27))
        }
        titleView = TextView(this).apply {
            text = "VoceaVie"
            textSize = 29f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.rgb(224, 230, 255))
        }
        root.addView(titleView)
        root.addView(label("Cititor de romane · Română offline"))
        root.addView(space(12))
        val import = button("＋  Importă roman TXT") { pickText() }
        root.addView(import)
        root.addView(space(8))
        root.addView(label("Capitol"))
        chapterSpinner = Spinner(this)
        root.addView(chapterSpinner)
        textPreview = EditText(this).apply {
            minLines = 8
            maxLines = 12
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            hint = "Importă un fișier TXT pentru a începe…"
            setBackgroundColor(Color.rgb(17, 27, 45))
            setPadding(14, 14, 14, 14)
        }
        root.addView(textPreview, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(space(12))
        root.addView(label("Voci și personaje"))
        root.addView(button("Atribuie voci personajelor") { showCharacterDialog() })
        root.addView(button("＋  Importă model vocal (.onnx / .json)") { pickModel() })
        root.addView(space(8))
        root.addView(button("Generează și exportă audio") {
            showMessage("Motorul neural nu este conectat încă. Aplicația nu va folosi vocea implicită a telefonului.")
        })
        status = label("Pregătit · Import TXT disponibil · Generarea audio urmează să fie conectată")
        status.textSize = 12f
        root.addView(space(8))
        root.addView(status)
        setContentView(root)
        updateChapterSpinner()
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(Color.rgb(169, 185, 214))
        setPadding(0, 5, 0, 5)
    }

    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        isAllCaps = false
        setOnClickListener { action() }
    }

    private fun space(dp: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, (dp * resources.displayMetrics.density).toInt())
    }

    private fun pickText() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/*"
        }
        startActivityForResult(i, PICK_TEXT)
    }

    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/json"))
        }
        startActivityForResult(i, PICK_MODEL)
    }

    @Deprecated("Using activity result API here keeps the starter dependency-free.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        when (requestCode) {
            PICK_TEXT -> loadText(uri)
            PICK_MODEL -> showMessage("Fișier selectat: ${uri.lastPathSegment}. Importul este demonstrativ; validarea modelului și conectarea la runtime urmează.")
        }
    }

    private fun loadText(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri) ?: throw IllegalStateException("Fișier inaccesibil")
            val text = BufferedReader(InputStreamReader(input, Charsets.UTF_8)).use { it.readText() }
            chapters.clear()
            val parts = Regex("(?im)^\\s*((?:capitolul|capitol|chapter)\\s+[^\\n]+)\\s*$")
                .findAll(text).toList()
            if (parts.isEmpty()) {
                chapters.add("Text integral" to text)
            } else {
                if (parts.first().range.first > 0) {
                    val intro = text.substring(0, parts.first().range.first).trim()
                    if (intro.isNotBlank()) chapters.add("Introducere" to intro)
                }
                parts.forEachIndexed { idx, match ->
                    val start = match.range.first
                    val end = if (idx + 1 < parts.size) parts[idx + 1].range.first else text.length
                    chapters.add(match.groupValues[1].trim() to text.substring(start, end).trim())
                }
            }
            updateChapterSpinner()
            if (chapters.isNotEmpty()) textPreview.setText(chapters[0].second)
            status.text = "Import reușit · ${chapters.size} secțiune/secțiuni detectate"
        } catch (e: Exception) {
            showMessage("Nu am putut citi fișierul. Încearcă un TXT UTF-8.")
        }
    }

    private fun updateChapterSpinner() {
        val names = if (chapters.isEmpty()) listOf("Niciun roman importat") else chapters.map { it.first }
        chapterSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        chapterSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position in chapters.indices) textPreview.setText(chapters[position].second)
            }
        }
    }

    private fun showCharacterDialog() {
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val input = EditText(this).apply { hint = "Numele personajului"; setSingleLine() }
        layout.addView(input)
        val options = arrayOf("Voce masculină", "Voce feminină", "Narator")
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, options)
        }
        layout.addView(spinner)
        android.app.AlertDialog.Builder(this)
            .setTitle("Adaugă personaj și preferință vocală")
            .setView(layout)
            .setPositiveButton("Salvează") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    voiceAssignments[name] = options[spinner.selectedItemPosition]
                    characters.add(name)
                    showMessage("$name: ${voiceAssignments[name]}. Atribuirea efectivă a vocii se activează după integrarea motorului TTS.")
                }
            }
            .setNegativeButton("Anulează", null).show()
    }

    private fun showMessage(message: String) {
        android.app.AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show()
    }
}
